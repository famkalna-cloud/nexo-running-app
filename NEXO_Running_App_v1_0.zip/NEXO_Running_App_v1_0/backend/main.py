
from fastapi import FastAPI, HTTPException, Depends, UploadFile, File, Form
from fastapi.middleware.cors import CORSMiddleware
from fastapi.responses import FileResponse, HTMLResponse, JSONResponse
from fastapi.staticfiles import StaticFiles
from pydantic import BaseModel, Field
from typing import Optional, List, Dict, Any
import sqlite3, os, uuid, json, hashlib, hmac, base64, time, secrets
from datetime import datetime, timezone
from pathlib import Path

APP_NAME = "NEXO Running App"
BASE_DIR = Path(__file__).resolve().parent.parent
DATA_DIR = BASE_DIR / "data"
UPLOAD_DIR = BASE_DIR / "uploads"
WEB_DIR = BASE_DIR / "web"
DB_PATH = DATA_DIR / "nexo.db"
DATA_DIR.mkdir(exist_ok=True)
UPLOAD_DIR.mkdir(exist_ok=True)
SECRET_FILE = DATA_DIR / ".secret"
if SECRET_FILE.exists():
    SECRET_KEY = SECRET_FILE.read_text().strip().encode()
else:
    SECRET_KEY = secrets.token_hex(32).encode()
    SECRET_FILE.write_text(SECRET_KEY.decode())

app = FastAPI(title=APP_NAME, version="1.0.0")
app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

def now() -> str:
    return datetime.now(timezone.utc).isoformat(timespec="seconds")

def new_id() -> str:
    return uuid.uuid4().hex

def db():
    conn = sqlite3.connect(DB_PATH)
    conn.row_factory = sqlite3.Row
    conn.execute("PRAGMA foreign_keys=ON")
    return conn

def row_to_dict(row):
    return dict(row) if row else None

def rows_to_list(rows):
    return [dict(r) for r in rows]

def json_dumps(obj):
    return json.dumps(obj, ensure_ascii=False, sort_keys=True)

def sha256_text(s: str) -> str:
    return hashlib.sha256(s.encode("utf-8")).hexdigest()

def sha256_bytes(b: bytes) -> str:
    return hashlib.sha256(b).hexdigest()

def hash_password(password: str, salt: Optional[str]=None):
    salt = salt or secrets.token_hex(16)
    digest = hashlib.pbkdf2_hmac("sha256", password.encode(), salt.encode(), 120000).hex()
    return salt, digest

def verify_password(password: str, salt: str, digest: str):
    return hmac.compare_digest(hash_password(password, salt)[1], digest)

def make_token(user_id: str):
    payload = {"uid": user_id, "iat": int(time.time()), "exp": int(time.time()) + 86400*14}
    body = base64.urlsafe_b64encode(json.dumps(payload).encode()).decode().rstrip("=")
    sig = hmac.new(SECRET_KEY, body.encode(), hashlib.sha256).hexdigest()
    return body + "." + sig

def read_token(token: str):
    try:
        body, sig = token.split(".", 1)
        expected = hmac.new(SECRET_KEY, body.encode(), hashlib.sha256).hexdigest()
        if not hmac.compare_digest(sig, expected):
            return None
        padded = body + "=" * (-len(body) % 4)
        payload = json.loads(base64.urlsafe_b64decode(padded.encode()).decode())
        if payload.get("exp", 0) < int(time.time()):
            return None
        return payload
    except Exception:
        return None

async def current_user(authorization: Optional[str]=None):
    # FastAPI cannot inject raw header here unless using Header; keep fallback below
    raise RuntimeError("Use get_current_user")

from fastapi import Header
async def get_current_user(authorization: Optional[str] = Header(default=None)):
    if not authorization or not authorization.lower().startswith("bearer "):
        raise HTTPException(401, "Authentication required")
    token = authorization.split(" ", 1)[1].strip()
    payload = read_token(token)
    if not payload:
        raise HTTPException(401, "Invalid or expired token")
    with db() as conn:
        user = conn.execute("SELECT * FROM users WHERE id=? AND status='ACTIVE'", (payload["uid"],)).fetchone()
        if not user:
            raise HTTPException(401, "User inactive or not found")
        return dict(user)

def require_admin(user):
    if user.get("role") not in ("SUPER_ADMIN", "ORG_ADMIN"):
        raise HTTPException(403, "Admin permission required")

def can_issue(user):
    return user.get("role") in ("SUPER_ADMIN", "ORG_ADMIN", "SUPERIOR", "OFFICER")

def audit(conn, entity_type: str, entity_id: str, action_type: str, actor_id: Optional[str], old_value: Any=None, new_value: Any=None):
    previous = conn.execute("SELECT event_hash FROM audit_logs ORDER BY id INTEGER DESC LIMIT 1").fetchone()
    # SQLite ORDER BY id with text? id is integer autoincrement below.

def add_audit(conn, entity_type: str, entity_id: str, action_type: str, actor_id: Optional[str], old_value: Any=None, new_value: Any=None):
    prev = conn.execute("SELECT event_hash FROM audit_logs ORDER BY audit_id DESC LIMIT 1").fetchone()
    prev_hash = prev["event_hash"] if prev else "GENESIS"
    created = now()
    payload = json_dumps({
        "entity_type": entity_type, "entity_id": entity_id, "action_type": action_type,
        "actor_id": actor_id, "old_value": old_value, "new_value": new_value,
        "prev_hash": prev_hash, "created_at": created
    })
    event_hash = sha256_text(prev_hash + payload)
    conn.execute("""
        INSERT INTO audit_logs(entity_type, entity_id, action_type, actor_id, old_value, new_value, prev_hash, event_hash, created_at)
        VALUES(?,?,?,?,?,?,?,?,?)
    """, (entity_type, entity_id, action_type, actor_id, json_dumps(old_value), json_dumps(new_value), prev_hash, event_hash, created))
    return event_hash

def init_db():
    with db() as conn:
        conn.executescript("""
        CREATE TABLE IF NOT EXISTS units(
            id TEXT PRIMARY KEY,
            name TEXT NOT NULL,
            parent_unit_id TEXT,
            organization_name TEXT NOT NULL,
            created_at TEXT NOT NULL
        );
        CREATE TABLE IF NOT EXISTS users(
            id TEXT PRIMARY KEY,
            name TEXT NOT NULL,
            mobile TEXT UNIQUE,
            email TEXT UNIQUE,
            employee_id TEXT UNIQUE,
            password_salt TEXT NOT NULL,
            password_hash TEXT NOT NULL,
            designation TEXT NOT NULL,
            rank TEXT,
            role TEXT NOT NULL,
            unit_id TEXT,
            reports_to_user_id TEXT,
            status TEXT NOT NULL DEFAULT 'ACTIVE',
            created_at TEXT NOT NULL,
            FOREIGN KEY(unit_id) REFERENCES units(id),
            FOREIGN KEY(reports_to_user_id) REFERENCES users(id)
        );
        CREATE TABLE IF NOT EXISTS conversations(
            id TEXT PRIMARY KEY,
            title TEXT NOT NULL,
            unit_id TEXT,
            created_by TEXT NOT NULL,
            created_at TEXT NOT NULL,
            FOREIGN KEY(unit_id) REFERENCES units(id),
            FOREIGN KEY(created_by) REFERENCES users(id)
        );
        CREATE TABLE IF NOT EXISTS conversation_members(
            conversation_id TEXT NOT NULL,
            user_id TEXT NOT NULL,
            PRIMARY KEY(conversation_id, user_id)
        );
        CREATE TABLE IF NOT EXISTS messages(
            id TEXT PRIMARY KEY,
            conversation_id TEXT NOT NULL,
            sender_id TEXT NOT NULL,
            message_text TEXT NOT NULL,
            message_type TEXT NOT NULL,
            priority TEXT NOT NULL DEFAULT 'NORMAL',
            attachment_id TEXT,
            created_at TEXT NOT NULL,
            FOREIGN KEY(conversation_id) REFERENCES conversations(id),
            FOREIGN KEY(sender_id) REFERENCES users(id)
        );
        CREATE TABLE IF NOT EXISTS commands(
            id TEXT PRIMARY KEY,
            message_id TEXT,
            title TEXT NOT NULL,
            description TEXT NOT NULL,
            command_type TEXT NOT NULL,
            issuer_user_id TEXT NOT NULL,
            priority TEXT NOT NULL,
            deadline TEXT,
            proof_required INTEGER NOT NULL DEFAULT 0,
            compliance_required INTEGER NOT NULL DEFAULT 1,
            command_hash TEXT NOT NULL,
            hierarchy_hash TEXT NOT NULL,
            recipient_hash TEXT NOT NULL,
            version INTEGER NOT NULL DEFAULT 1,
            status TEXT NOT NULL DEFAULT 'ISSUED',
            created_at TEXT NOT NULL,
            FOREIGN KEY(message_id) REFERENCES messages(id),
            FOREIGN KEY(issuer_user_id) REFERENCES users(id)
        );
        CREATE TABLE IF NOT EXISTS command_recipients(
            id TEXT PRIMARY KEY,
            command_id TEXT NOT NULL,
            user_id TEXT NOT NULL,
            status TEXT NOT NULL DEFAULT 'ASSIGNED',
            delivered_at TEXT,
            seen_at TEXT,
            acknowledged_at TEXT,
            in_progress_at TEXT,
            completed_at TEXT,
            proof_submitted_at TEXT,
            verified_at TEXT,
            closed_at TEXT,
            proof_text TEXT,
            proof_file_id TEXT,
            verified_by TEXT,
            remarks TEXT,
            last_updated TEXT NOT NULL,
            UNIQUE(command_id, user_id),
            FOREIGN KEY(command_id) REFERENCES commands(id),
            FOREIGN KEY(user_id) REFERENCES users(id)
        );
        CREATE TABLE IF NOT EXISTS clarifications(
            id TEXT PRIMARY KEY,
            command_id TEXT NOT NULL,
            asked_by TEXT NOT NULL,
            question_text TEXT NOT NULL,
            answered_by TEXT,
            answer_text TEXT,
            status TEXT NOT NULL DEFAULT 'OPEN',
            asked_at TEXT NOT NULL,
            answered_at TEXT,
            FOREIGN KEY(command_id) REFERENCES commands(id)
        );
        CREATE TABLE IF NOT EXISTS attachments(
            id TEXT PRIMARY KEY,
            filename TEXT NOT NULL,
            stored_path TEXT NOT NULL,
            sha256 TEXT NOT NULL,
            uploaded_by TEXT NOT NULL,
            created_at TEXT NOT NULL
        );
        CREATE TABLE IF NOT EXISTS audit_logs(
            audit_id INTEGER PRIMARY KEY AUTOINCREMENT,
            entity_type TEXT NOT NULL,
            entity_id TEXT NOT NULL,
            action_type TEXT NOT NULL,
            actor_id TEXT,
            old_value TEXT,
            new_value TEXT,
            prev_hash TEXT NOT NULL,
            event_hash TEXT NOT NULL,
            created_at TEXT NOT NULL
        );
        """)
        conn.commit()

@app.on_event("startup")
def startup():
    init_db()

@app.get("/", response_class=HTMLResponse)
def root():
    return FileResponse(WEB_DIR / "mobile" / "index.html")

@app.get("/mobile/", response_class=HTMLResponse)
def mobile_home():
    return FileResponse(WEB_DIR / "mobile" / "index.html")

@app.get("/admin/", response_class=HTMLResponse)
def admin_home():
    return FileResponse(WEB_DIR / "admin" / "index.html")

app.mount("/static/mobile", StaticFiles(directory=str(WEB_DIR / "mobile")), name="mobile_static")
app.mount("/static/admin", StaticFiles(directory=str(WEB_DIR / "admin")), name="admin_static")

class FirstAdmin(BaseModel):
    organization_name: str = Field(min_length=2)
    unit_name: str = Field(min_length=2)
    name: str = Field(min_length=2)
    mobile: Optional[str] = None
    email: Optional[str] = None
    employee_id: Optional[str] = None
    password: str = Field(min_length=6)
    designation: str = "Founder Admin"

class LoginBody(BaseModel):
    login: str
    password: str

class UserCreate(BaseModel):
    name: str
    mobile: Optional[str] = None
    email: Optional[str] = None
    employee_id: Optional[str] = None
    password: str = Field(min_length=6)
    designation: str
    rank: Optional[str] = None
    role: str = "STAFF"
    unit_id: Optional[str] = None
    reports_to_user_id: Optional[str] = None

class UnitCreate(BaseModel):
    name: str
    parent_unit_id: Optional[str] = None
    organization_name: Optional[str] = None

class ConversationCreate(BaseModel):
    title: str
    unit_id: Optional[str] = None
    member_ids: List[str] = []

class MessageCreate(BaseModel):
    conversation_id: str
    message_text: str
    message_type: str = "GENERAL"
    priority: str = "NORMAL"

class CommandCreate(BaseModel):
    title: str
    description: str
    command_type: str = "INSTRUCTION"
    priority: str = "NORMAL"
    deadline: Optional[str] = None
    proof_required: bool = False
    compliance_required: bool = True
    assigned_user_ids: List[str] = []
    assigned_roles: List[str] = []
    assigned_unit_ids: List[str] = []
    conversation_id: Optional[str] = None

class StatusUpdate(BaseModel):
    status: str
    proof_text: Optional[str] = None
    remarks: Optional[str] = None

class VerifyBody(BaseModel):
    user_id: str
    remarks: Optional[str] = None

class ClarificationCreate(BaseModel):
    question_text: str

class ClarificationAnswer(BaseModel):
    answer_text: str

@app.get("/api/setup/status")
def setup_status():
    with db() as conn:
        c = conn.execute("SELECT COUNT(*) AS c FROM users").fetchone()["c"]
        return {"ready": c > 0, "user_count": c, "app": APP_NAME}

@app.post("/api/setup/first-admin")
def create_first_admin(body: FirstAdmin):
    with db() as conn:
        c = conn.execute("SELECT COUNT(*) AS c FROM users").fetchone()["c"]
        if c > 0:
            raise HTTPException(400, "First admin already exists")
        unit_id = new_id()
        conn.execute("INSERT INTO units(id,name,parent_unit_id,organization_name,created_at) VALUES(?,?,?,?,?)", (unit_id, body.unit_name, None, body.organization_name, now()))
        salt, ph = hash_password(body.password)
        user_id = new_id()
        conn.execute("""INSERT INTO users(id,name,mobile,email,employee_id,password_salt,password_hash,designation,rank,role,unit_id,reports_to_user_id,status,created_at)
                     VALUES(?,?,?,?,?,?,?,?,?,?,?,?,?,?)""",
                     (user_id, body.name, body.mobile, body.email, body.employee_id, salt, ph, body.designation, body.designation, "SUPER_ADMIN", unit_id, None, "ACTIVE", now()))
        conv_id = new_id()
        conn.execute("INSERT INTO conversations(id,title,unit_id,created_by,created_at) VALUES(?,?,?,?,?)", (conv_id, f"{body.unit_name} Official Space", unit_id, user_id, now()))
        conn.execute("INSERT INTO conversation_members(conversation_id,user_id) VALUES(?,?)", (conv_id, user_id))
        add_audit(conn, "USER", user_id, "FIRST_ADMIN_CREATED", user_id, None, {"organization": body.organization_name})
        conn.commit()
        return {"ok": True, "token": make_token(user_id), "user_id": user_id}

@app.post("/api/auth/login")
def login(body: LoginBody):
    with db() as conn:
        user = conn.execute("""SELECT * FROM users WHERE (mobile=? OR email=? OR employee_id=?) AND status='ACTIVE'""", (body.login, body.login, body.login)).fetchone()
        if not user or not verify_password(body.password, user["password_salt"], user["password_hash"]):
            raise HTTPException(401, "Invalid login or password")
        token = make_token(user["id"])
        add_audit(conn, "USER", user["id"], "LOGIN", user["id"], None, {"login": body.login})
        conn.commit()
        d = dict(user); d.pop("password_salt", None); d.pop("password_hash", None)
        return {"token": token, "user": d}

@app.get("/api/me")
def me(user=Depends(get_current_user)):
    u = dict(user); u.pop("password_salt", None); u.pop("password_hash", None)
    return u

@app.get("/api/units")
def list_units(user=Depends(get_current_user)):
    with db() as conn:
        return rows_to_list(conn.execute("SELECT * FROM units ORDER BY organization_name,name").fetchall())

@app.post("/api/units")
def create_unit(body: UnitCreate, user=Depends(get_current_user)):
    require_admin(user)
    with db() as conn:
        org = body.organization_name or conn.execute("SELECT organization_name FROM units WHERE id=?", (user.get("unit_id"),)).fetchone()["organization_name"]
        unit_id = new_id()
        conn.execute("INSERT INTO units(id,name,parent_unit_id,organization_name,created_at) VALUES(?,?,?,?,?)", (unit_id, body.name, body.parent_unit_id, org, now()))
        add_audit(conn, "UNIT", unit_id, "CREATED", user["id"], None, body.dict())
        conn.commit()
        return {"id": unit_id}

@app.get("/api/users")
def list_users(user=Depends(get_current_user)):
    with db() as conn:
        rows = conn.execute("""SELECT u.id,u.name,u.mobile,u.email,u.employee_id,u.designation,u.rank,u.role,u.unit_id,u.reports_to_user_id,u.status,u.created_at,un.name as unit_name
                               FROM users u LEFT JOIN units un ON un.id=u.unit_id ORDER BY u.role,u.name""").fetchall()
        return rows_to_list(rows)

@app.post("/api/users")
def create_user(body: UserCreate, user=Depends(get_current_user)):
    require_admin(user)
    with db() as conn:
        salt, ph = hash_password(body.password)
        user_id = new_id()
        unit_id = body.unit_id or user.get("unit_id")
        try:
            conn.execute("""INSERT INTO users(id,name,mobile,email,employee_id,password_salt,password_hash,designation,rank,role,unit_id,reports_to_user_id,status,created_at)
                         VALUES(?,?,?,?,?,?,?,?,?,?,?,?,?,?)""",
                         (user_id, body.name, body.mobile, body.email, body.employee_id, salt, ph, body.designation, body.rank, body.role, unit_id, body.reports_to_user_id, "ACTIVE", now()))
        except sqlite3.IntegrityError as e:
            raise HTTPException(400, f"Duplicate mobile/email/employee ID: {e}")
        convs = conn.execute("SELECT id FROM conversations WHERE unit_id=?", (unit_id,)).fetchall()
        for c in convs:
            conn.execute("INSERT OR IGNORE INTO conversation_members(conversation_id,user_id) VALUES(?,?)", (c["id"], user_id))
        add_audit(conn, "USER", user_id, "CREATED", user["id"], None, body.dict())
        conn.commit()
        return {"id": user_id}

@app.get("/api/hierarchy")
def hierarchy(user=Depends(get_current_user)):
    with db() as conn:
        users = rows_to_list(conn.execute("SELECT id,name,designation,rank,role,unit_id,reports_to_user_id,status FROM users ORDER BY name").fetchall())
        units = rows_to_list(conn.execute("SELECT * FROM units ORDER BY name").fetchall())
        return {"units": units, "users": users}

@app.get("/api/conversations")
def list_conversations(user=Depends(get_current_user)):
    with db() as conn:
        rows = conn.execute("""SELECT c.* FROM conversations c
                               JOIN conversation_members m ON m.conversation_id=c.id
                               WHERE m.user_id=? ORDER BY c.created_at DESC""", (user["id"],)).fetchall()
        return rows_to_list(rows)

@app.post("/api/conversations")
def create_conversation(body: ConversationCreate, user=Depends(get_current_user)):
    with db() as conn:
        cid = new_id()
        conn.execute("INSERT INTO conversations(id,title,unit_id,created_by,created_at) VALUES(?,?,?,?,?)", (cid, body.title, body.unit_id or user.get("unit_id"), user["id"], now()))
        members = set(body.member_ids + [user["id"]])
        if body.unit_id:
            for r in conn.execute("SELECT id FROM users WHERE unit_id=? AND status='ACTIVE'", (body.unit_id,)).fetchall():
                members.add(r["id"])
        for uid in members:
            conn.execute("INSERT OR IGNORE INTO conversation_members(conversation_id,user_id) VALUES(?,?)", (cid, uid))
        add_audit(conn, "CONVERSATION", cid, "CREATED", user["id"], None, body.dict())
        conn.commit()
        return {"id": cid}

@app.get("/api/messages")
def list_messages(conversation_id: str, user=Depends(get_current_user)):
    with db() as conn:
        member = conn.execute("SELECT 1 FROM conversation_members WHERE conversation_id=? AND user_id=?", (conversation_id, user["id"])).fetchone()
        if not member:
            raise HTTPException(403, "Not a member of this conversation")
        rows = conn.execute("""SELECT m.*,u.name as sender_name,u.designation as sender_designation FROM messages m
                               JOIN users u ON u.id=m.sender_id WHERE conversation_id=? ORDER BY created_at ASC""", (conversation_id,)).fetchall()
        return rows_to_list(rows)

@app.post("/api/messages")
def send_message(body: MessageCreate, user=Depends(get_current_user)):
    with db() as conn:
        member = conn.execute("SELECT 1 FROM conversation_members WHERE conversation_id=? AND user_id=?", (body.conversation_id, user["id"])).fetchone()
        if not member:
            raise HTTPException(403, "Not a member of this conversation")
        mid = new_id()
        conn.execute("INSERT INTO messages(id,conversation_id,sender_id,message_text,message_type,priority,created_at) VALUES(?,?,?,?,?,?,?)",
                     (mid, body.conversation_id, user["id"], body.message_text, body.message_type.upper(), body.priority.upper(), now()))
        add_audit(conn, "MESSAGE", mid, "SENT", user["id"], None, body.dict())
        conn.commit()
        return {"id": mid}

def resolve_recipients(conn, body: CommandCreate):
    ids = set(body.assigned_user_ids)
    for role in body.assigned_roles:
        for r in conn.execute("SELECT id FROM users WHERE role=? AND status='ACTIVE'", (role,)).fetchall():
            ids.add(r["id"])
    for unit in body.assigned_unit_ids:
        for r in conn.execute("SELECT id FROM users WHERE unit_id=? AND status='ACTIVE'", (unit,)).fetchall():
            ids.add(r["id"])
    return sorted(ids)

def reporting_chain(conn, user_id):
    chain = []
    seen = set()
    cur = user_id
    while cur and cur not in seen:
        seen.add(cur)
        r = conn.execute("SELECT id,name,designation,reports_to_user_id FROM users WHERE id=?", (cur,)).fetchone()
        if not r: break
        chain.append({"id": r["id"], "name": r["name"], "designation": r["designation"]})
        cur = r["reports_to_user_id"]
    return chain

@app.post("/api/commands")
def create_command(body: CommandCreate, user=Depends(get_current_user)):
    if not can_issue(user):
        raise HTTPException(403, "You cannot issue official instructions")
    with db() as conn:
        recipients = resolve_recipients(conn, body)
        recipients = [r for r in recipients if r != user["id"]]
        if not recipients:
            raise HTTPException(400, "No recipients selected")
        mid = None
        if body.conversation_id:
            mid = new_id()
            conn.execute("INSERT INTO messages(id,conversation_id,sender_id,message_text,message_type,priority,created_at) VALUES(?,?,?,?,?,?,?)",
                         (mid, body.conversation_id, user["id"], body.description, body.command_type.upper(), body.priority.upper(), now()))
        hierarchy = reporting_chain(conn, user["id"])
        hierarchy_hash = sha256_text(json_dumps(hierarchy))
        recipient_hash = sha256_text(json_dumps(recipients))
        created = now()
        command_raw = json_dumps({"title": body.title, "description": body.description, "type": body.command_type, "issuer": user["id"], "recipients": recipients, "deadline": body.deadline, "created": created})
        command_hash = sha256_text(command_raw + hierarchy_hash + recipient_hash)
        cid = new_id()
        conn.execute("""INSERT INTO commands(id,message_id,title,description,command_type,issuer_user_id,priority,deadline,proof_required,compliance_required,command_hash,hierarchy_hash,recipient_hash,version,status,created_at)
                     VALUES(?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)""",
                     (cid, mid, body.title, body.description, body.command_type.upper(), user["id"], body.priority.upper(), body.deadline, int(body.proof_required), int(body.compliance_required), command_hash, hierarchy_hash, recipient_hash, 1, "ISSUED", created))
        for uid in recipients:
            rid = new_id()
            conn.execute("""INSERT INTO command_recipients(id,command_id,user_id,status,delivered_at,last_updated) VALUES(?,?,?,?,?,?)""", (rid, cid, uid, "DELIVERED", now(), now()))
        add_audit(conn, "COMMAND", cid, "ISSUED", user["id"], None, {"command_hash": command_hash, "recipients": len(recipients)})
        conn.commit()
        return {"id": cid, "recipients": len(recipients), "command_hash": command_hash}

@app.get("/api/commands")
def list_commands(scope: str="all", user=Depends(get_current_user)):
    with db() as conn:
        if scope == "issued":
            rows = conn.execute("""SELECT c.*,u.name as issuer_name FROM commands c JOIN users u ON u.id=c.issuer_user_id WHERE issuer_user_id=? ORDER BY created_at DESC""", (user["id"],)).fetchall()
        elif scope == "mine":
            rows = conn.execute("""SELECT c.*,u.name as issuer_name,cr.status as my_status,cr.last_updated as my_last_updated
                                   FROM commands c JOIN command_recipients cr ON cr.command_id=c.id JOIN users u ON u.id=c.issuer_user_id
                                   WHERE cr.user_id=? ORDER BY c.created_at DESC""", (user["id"],)).fetchall()
        else:
            rows = conn.execute("""SELECT DISTINCT c.*,u.name as issuer_name FROM commands c JOIN users u ON u.id=c.issuer_user_id
                                   LEFT JOIN command_recipients cr ON cr.command_id=c.id
                                   WHERE c.issuer_user_id=? OR cr.user_id=? ORDER BY c.created_at DESC""", (user["id"], user["id"])).fetchall()
        return rows_to_list(rows)

@app.get("/api/commands/{command_id}")
def get_command(command_id: str, user=Depends(get_current_user)):
    with db() as conn:
        c = conn.execute("SELECT c.*,u.name as issuer_name,u.designation as issuer_designation FROM commands c JOIN users u ON u.id=c.issuer_user_id WHERE c.id=?", (command_id,)).fetchone()
        if not c: raise HTTPException(404, "Command not found")
        allowed = c["issuer_user_id"] == user["id"] or conn.execute("SELECT 1 FROM command_recipients WHERE command_id=? AND user_id=?", (command_id, user["id"])).fetchone()
        if not allowed and user["role"] not in ("SUPER_ADMIN", "ORG_ADMIN"):
            raise HTTPException(403, "Not allowed")
        return dict(c)

@app.get("/api/commands/{command_id}/compliance")
def command_compliance(command_id: str, user=Depends(get_current_user)):
    with db() as conn:
        c = conn.execute("SELECT * FROM commands WHERE id=?", (command_id,)).fetchone()
        if not c: raise HTTPException(404, "Command not found")
        allowed = c["issuer_user_id"] == user["id"] or user["role"] in ("SUPER_ADMIN", "ORG_ADMIN") or conn.execute("SELECT 1 FROM command_recipients WHERE command_id=? AND user_id=?", (command_id, user["id"])).fetchone()
        if not allowed: raise HTTPException(403, "Not allowed")
        rows = rows_to_list(conn.execute("""SELECT cr.*,u.name,u.designation,u.role,u.unit_id FROM command_recipients cr JOIN users u ON u.id=cr.user_id WHERE command_id=? ORDER BY u.name""", (command_id,)).fetchall())
        counts = {"TOTAL": len(rows), "DELIVERED":0, "SEEN":0, "ACKNOWLEDGED":0, "IN_PROGRESS":0, "COMPLETED":0, "PROOF_SUBMITTED":0, "VERIFIED":0, "CLOSED":0, "CLARIFICATION":0}
        order = ["DELIVERED", "SEEN", "ACKNOWLEDGED", "IN_PROGRESS", "COMPLETED", "PROOF_SUBMITTED", "VERIFIED", "CLOSED"]
        idx = {s:i for i,s in enumerate(order)}
        for r in rows:
            st = r["status"]
            if st in counts: counts[st] += 1
            if st in idx:
                # cumulative stats useful for dashboard
                for s in order[:idx[st]+1]:
                    counts.setdefault(s+"_OR_MORE", 0); counts[s+"_OR_MORE"] += 1
        return {"command": dict(c), "summary": counts, "recipients": rows}

@app.post("/api/commands/{command_id}/my-status")
def update_my_status(command_id: str, body: StatusUpdate, user=Depends(get_current_user)):
    allowed_status = {"SEEN", "ACKNOWLEDGED", "IN_PROGRESS", "COMPLETED", "PROOF_SUBMITTED", "CLARIFICATION"}
    st = body.status.upper()
    if st not in allowed_status: raise HTTPException(400, "Invalid status")
    with db() as conn:
        cr = conn.execute("SELECT * FROM command_recipients WHERE command_id=? AND user_id=?", (command_id, user["id"])).fetchone()
        if not cr: raise HTTPException(403, "This command is not assigned to you")
        field = {"SEEN":"seen_at", "ACKNOWLEDGED":"acknowledged_at", "IN_PROGRESS":"in_progress_at", "COMPLETED":"completed_at", "PROOF_SUBMITTED":"proof_submitted_at", "CLARIFICATION":"seen_at"}[st]
        old = dict(cr)
        conn.execute(f"UPDATE command_recipients SET status=?, {field}=?, proof_text=COALESCE(?,proof_text), remarks=COALESCE(?,remarks), last_updated=? WHERE id=?", (st, now(), body.proof_text, body.remarks, now(), cr["id"]))
        add_audit(conn, "COMMAND_RECIPIENT", cr["id"], f"STATUS_{st}", user["id"], old.get("status"), st)
        conn.commit()
        return {"ok": True, "status": st}

@app.post("/api/commands/{command_id}/verify")
def verify_recipient(command_id: str, body: VerifyBody, user=Depends(get_current_user)):
    with db() as conn:
        c = conn.execute("SELECT * FROM commands WHERE id=?", (command_id,)).fetchone()
        if not c: raise HTTPException(404, "Command not found")
        if c["issuer_user_id"] != user["id"] and user["role"] not in ("SUPER_ADMIN", "ORG_ADMIN"):
            raise HTTPException(403, "Only issuer/admin can verify")
        cr = conn.execute("SELECT * FROM command_recipients WHERE command_id=? AND user_id=?", (command_id, body.user_id)).fetchone()
        if not cr: raise HTTPException(404, "Recipient not found")
        conn.execute("UPDATE command_recipients SET status='VERIFIED', verified_at=?, verified_by=?, remarks=COALESCE(?,remarks), last_updated=? WHERE id=?", (now(), user["id"], body.remarks, now(), cr["id"]))
        add_audit(conn, "COMMAND_RECIPIENT", cr["id"], "VERIFIED", user["id"], cr["status"], "VERIFIED")
        conn.commit()
        return {"ok": True}

@app.post("/api/commands/{command_id}/clarifications")
def ask_clarification(command_id: str, body: ClarificationCreate, user=Depends(get_current_user)):
    with db() as conn:
        if not conn.execute("SELECT 1 FROM command_recipients WHERE command_id=? AND user_id=?", (command_id, user["id"])).fetchone():
            raise HTTPException(403, "Only assigned recipient can ask clarification")
        cid = new_id()
        conn.execute("INSERT INTO clarifications(id,command_id,asked_by,question_text,status,asked_at) VALUES(?,?,?,?,?,?)", (cid, command_id, user["id"], body.question_text, "OPEN", now()))
        add_audit(conn, "CLARIFICATION", cid, "ASKED", user["id"], None, body.question_text)
        conn.commit()
        return {"id": cid}

@app.get("/api/commands/{command_id}/clarifications")
def list_clarifications(command_id: str, user=Depends(get_current_user)):
    with db() as conn:
        rows = conn.execute("""SELECT cl.*,au.name as asked_by_name,an.name as answered_by_name FROM clarifications cl
                               JOIN users au ON au.id=cl.asked_by LEFT JOIN users an ON an.id=cl.answered_by WHERE command_id=? ORDER BY asked_at""", (command_id,)).fetchall()
        return rows_to_list(rows)

@app.post("/api/clarifications/{clarification_id}/answer")
def answer_clarification(clarification_id: str, body: ClarificationAnswer, user=Depends(get_current_user)):
    with db() as conn:
        cl = conn.execute("SELECT cl.*,c.issuer_user_id FROM clarifications cl JOIN commands c ON c.id=cl.command_id WHERE cl.id=?", (clarification_id,)).fetchone()
        if not cl: raise HTTPException(404, "Clarification not found")
        if cl["issuer_user_id"] != user["id"] and user["role"] not in ("SUPER_ADMIN", "ORG_ADMIN"):
            raise HTTPException(403, "Only issuer/admin can answer")
        conn.execute("UPDATE clarifications SET answered_by=?, answer_text=?, status='ANSWERED', answered_at=? WHERE id=?", (user["id"], body.answer_text, now(), clarification_id))
        add_audit(conn, "CLARIFICATION", clarification_id, "ANSWERED", user["id"], None, body.answer_text)
        conn.commit()
        return {"ok": True}

@app.post("/api/files")
async def upload_file(file: UploadFile = File(...), user=Depends(get_current_user)):
    data = await file.read()
    fid = new_id()
    safe = ''.join(ch for ch in file.filename if ch.isalnum() or ch in '._- ')[:150] or 'file.bin'
    path = UPLOAD_DIR / f"{fid}_{safe}"
    path.write_bytes(data)
    digest = sha256_bytes(data)
    with db() as conn:
        conn.execute("INSERT INTO attachments(id,filename,stored_path,sha256,uploaded_by,created_at) VALUES(?,?,?,?,?,?)", (fid, safe, str(path), digest, user["id"], now()))
        add_audit(conn, "FILE", fid, "UPLOADED", user["id"], None, {"filename": safe, "sha256": digest})
        conn.commit()
    return {"id": fid, "filename": safe, "sha256": digest}

@app.get("/api/audit")
def list_audit(limit: int=100, user=Depends(get_current_user)):
    require_admin(user)
    with db() as conn:
        return rows_to_list(conn.execute("SELECT * FROM audit_logs ORDER BY audit_id DESC LIMIT ?", (limit,)).fetchall())

@app.get("/api/health")
def health():
    with db() as conn:
        users = conn.execute("SELECT COUNT(*) c FROM users").fetchone()["c"]
        commands = conn.execute("SELECT COUNT(*) c FROM commands").fetchone()["c"]
    return {"ok": True, "app": APP_NAME, "users": users, "commands": commands, "time": now()}
