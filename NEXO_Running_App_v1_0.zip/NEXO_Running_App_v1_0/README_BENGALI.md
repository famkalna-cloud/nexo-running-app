# NEXO Running App v1.0 — No Demo Data

এটা demo/mockup নয়। এই version real backend + database দিয়ে চলে। প্রথমবার run করলে database খালি থাকবে এবং আপনাকে নিজের First Admin তৈরি করতে হবে।

## কী আছে

- FastAPI real backend
- SQLite real database: `data/nexo.db`
- First Admin setup, no demo user
- Real login with password hashing
- Organization unit + hierarchy
- Real communication / official space
- Instruction / Order issue
- Recipient-wise compliance: Delivered, Seen, Acknowledged, In Progress, Completed, Verified
- Clarification API
- File upload API
- Audit hash-chain
- Mobile web app
- Admin web panel
- Android WebView source folder
- Docker Compose support

## Windows এ চালানো

1. ZIP unzip করুন
2. `START_WINDOWS.bat` double click করুন
3. Browser খুলুন:

Mobile App:
```
http://localhost:8000/mobile/
```

Admin Panel:
```
http://localhost:8000/admin/
```

## প্রথম ব্যবহার

1. Mobile app খুললে First-time Setup দেখাবে
2. Organization name, unit name, admin name, mobile/login, password দিন
3. Admin create হলে app-এ ঢুকে যাবে
4. Profile tab থেকে user add করুন
5. Communication থেকে instruction/order issue করুন
6. Recipient login করে Orders tab থেকে status update করবে
7. Issuer Compliance tab থেকে progress দেখবে ও Verify করবে

## মোবাইলে চালানো

PC এবং Mobile একই Wi-Fi-তে রাখুন। PC-এর IP বের করুন:

Windows CMD:
```
ipconfig
```

তারপর mobile Chrome-এ খুলুন:
```
http://YOUR_PC_IP:8000/mobile/
```

## Android APK

`android/` folder Android Studio-তে open করুন। WebView app backend URL-এ যাবে। `strings.xml`-এ আপনার server URL বসাতে হবে।

## গুরুত্বপূর্ণ

এই environment-এ Android SDK/Gradle নেই, তাই compiled APK এখানে build করা হয়নি। কিন্তু app backend + database সহ real running full-stack হিসেবে ready। APK build করতে Android Studio লাগবে।

## Next Production Steps

- PostgreSQL migration
- OTP/SMS login
- Push notification
- WebSocket real-time updates
- Role permission hardening
- TLS/HTTPS deployment
- Cloud server deployment
- Android signed release APK
